﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Route71
{
    public partial class formDashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.loadDefaultDetails();
        }
        /// <summary>
        /// Load the default details of the form
        /// </summary>
        public void loadDefaultDetails()
        {
            SiteMaster.pageTitle = "Dashboard";
            SiteMaster.moduleName = "Admin";
            SiteMaster.Home = "Home";
        }
    }
}