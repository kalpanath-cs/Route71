﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Route71
{
    public partial class FormLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.loadDefaultValue();
        }
        /// <summary>
        /// Load the default vlaues for the forms
        /// </summary>
        public void loadDefaultValue()
        {
            lblApplciationName.Text = "Group reporting portal";
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "admin" && txtPassword.Text == "admin")
            {
                Session["LoggedInUsername"] = txtUsername.Text.ToString();
                Response.Redirect("formDashboard.aspx");
            }
            else
            {
                AlertMessage("Invalid username and password!!");
            }
        }

        protected void btnSignUp_Click(object sender, EventArgs e)
        {
            Response.Redirect("formRegister.aspx");
        }
        public static void AlertMessage(string MessageText)
        {
            Page page = HttpContext.Current.CurrentHandler as Page;
            page.ClientScript.RegisterStartupScript(typeof(Page), "Script", "<script language='javascript'>alert('" + MessageText + "');</script>");
        }
    }
}