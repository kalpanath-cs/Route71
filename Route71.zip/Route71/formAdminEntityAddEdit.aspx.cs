﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Route71
{
    public partial class formAdminEntityAddEdit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.loadDefaultDetails();
        }
        public void loadDefaultDetails()
        {
            lblGroupTitle.Text = "Add Entity detail informations";
            SiteMaster.pageTitle = "Entity details";
            SiteMaster.moduleName = "Admin";
            SiteMaster.Home = "Home";
        }
        /// <summary>
        /// Method to check and validate the check box options
        /// </summary>
        public void checkBoxValidations()
        {
            if (chkFullOwned.Checked == true)
            {
                chkJointVenture.Checked = false;
                divJointVenture.Visible = true;
                txtOtherPartners.Text = "";
                txtShareHolding.Text = "";
                lblTotal.Text = "";
            }
            else if (chkJointVenture.Checked == true)
            {

                divJointVenture.Visible = true;
            }
        }
        /// <summary>
        /// On checkbox checked event controls need to be validated
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void chkFullOwned_CheckedChanged(object sender, EventArgs e)
        {
            chkJointVenture.Checked = false;
            divJointVenture.Visible = false;
            txtOtherPartners.Text = "";
            txtShareHolding.Text = "";
            lblTotal.Text = "";
        }

        protected void chkJointVenture_CheckedChanged(object sender, EventArgs e)
        {
            chkFullOwned.Checked = false;
            divJointVenture.Visible = true;
        }
    }
}