﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Route71.Startup))]
namespace Route71
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
           // ConfigureAuth(app);
        }
    }
}
