﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Route71
{
    public partial class formAdminUserAddEdit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.loadDefaultDetails();
        }
        public void loadDefaultDetails()
        {
            lblGroupTitle.Text = "Add User detail informations";
            SiteMaster.pageTitle = "User details";
            SiteMaster.moduleName = "Admin";
            SiteMaster.Home = "Home";
        }
    }
}