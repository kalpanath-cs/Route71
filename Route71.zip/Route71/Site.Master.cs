﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Principal;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Identity;
using System.Configuration;
namespace Route71
{
    public partial class SiteMaster : MasterPage
    {
        public static string pageTitle;
        public static string moduleName;
        public static string Home;
        protected void Page_Init(object sender, EventArgs e)

        {
            lblApplicationName.Text = ConfigurationManager.AppSettings["ApplicationName"].ToString();
            lblPageNameTitle.Text = pageTitle;
        }
        protected void Page_Load(object sender, EventArgs e)
        {
        }
        protected void Unnamed_LoggingOut(object sender, LoginCancelEventArgs e)
        {
        }
    }

}